using UnityEngine;
using LSL;
using System;
using System.Collections;
using System.Collections.Generic;
//Check: https://github.com/labstreaminglayer/liblsl-Csharp/blob/master/README-Unity.md
public class LSLManager : MonoBehaviour
{
    //Adjust as necessary
    string OutletStreamName = "Unity.MarkerStream";
    string OutletStreamType = "Unity.Marker";
    string OutletStreamID = ""; 
    string InletStreamType = "Python.Classification";
    string InletStreamName = "CCA_Classifier_Output"; 
    public int ChannelCount = 1;
    private string[] sample = new string[1];

    //LSL outlets
    private StreamOutlet markerOutlet;
    private StreamInfo streamInfo;

    //LSL inlet
    private StreamInlet classifierInlet;
    private StreamInfo[] streamInfos;
    private int channelCount = 0;

    //Action Events
    // Event: Notify others when a classification is received
    public static event Action<int> OnClassificationReceived; 

    // Event: Listen for requests to start stimulus
    public static event Action OnStartStimulus;

    #region Singleton Pattern
    public static LSLManager Instance { get; private set; }
    #endregion

    private void Start()
    {

        //Create a hash ID for the stream
        var hash = new Hash128();
        hash.Append(OutletStreamName);
        hash.Append(OutletStreamType);
        hash.Append(gameObject.GetInstanceID());
        OutletStreamID = hash.ToString(); 

        //Create the stimulus event metadata 
        //SStreamInfo(string name, string type, int channel_count = 1, double nominal_srate = LSL.IRREGULAR_RATE, channel_format_t channel_format = channel_format_t.cf_float32, string source_id = "")
        //StreamInfo streamInfo = new StreamInfo(StreamName, StreamType, 1,LSL.LSL.IRREGULAR_RATE, channel_format_t.cf_string, hash.ToString());,

        //Outlet for Unity -> Python
        streamInfo = new StreamInfo(OutletStreamName, OutletStreamType, 1,LSL.LSL.IRREGULAR_RATE,channel_format_t.cf_string,OutletStreamID);
        markerOutlet = new StreamOutlet(streamInfo);
        sample[0] = "Initializing";
        markerOutlet.push_sample(sample);
        Debug.Log("Output stream initialized");

        //send initial configuration values
        sendInitialConfig(); 

        //Initialize inlet for Python -> Unity
        //StartCoroutine(InitializeClassifierInlet()); 
    }

    void Update()
    {
        // Receive classification result from Python
        if (classifierInlet != null)
        {
            string[] sample = new string[channelCount]; 
            double timestamp = classifierInlet.pull_sample(sample, 0.0f);

            //Tries to pull a sample from the LSL stream into the sample array.
            //The 0.0f timeout means non - blocking: it returns immediately.
            //If a sample is available, it's copied into sample[0], and the LSL timestamp is returned.
            //If no sample is available, it returns 0.0.

            
            if (timestamp != 0.0)
            {
                //Asuming python sends one value at a time (1,2,3)
                int classifiedIndex = int.Parse(sample[0]);
                Debug.Log($"Received classification: {classifiedIndex}");
                // Fire the event in MuseumManager
                OnClassificationReceived?.Invoke(classifiedIndex);
            }
        }
        else { //Search and Open the stream
            //The resolve_stream() function is used to search for streams on the network based on this metadata.
            //The first string, "type", is the metadata field you're querying.
            //The second string, "Markers", is the value you're filtering for.
            //streamInfos = LSL.LSL.resolve_stream("type", InletStreamType, 1, 0.0);
            streamInfos = LSL.LSL.resolve_stream("name", InletStreamName, 1, 0.0);
            if (streamInfos.Length > 0)
            {
                classifierInlet = new StreamInlet(streamInfos[0]);
                channelCount = classifierInlet.info().channel_count();
                classifierInlet.open_stream();
                Debug.Log("LSL Classifier Inlet connected.");
            }
            Debug.LogWarning("No Classifier Inlet stream found.");

        }
    }

    public void SendMarker(string markerLabel)
    {
        string[] sample = new string[] { markerLabel };
        markerOutlet.push_sample(sample);
        Debug.Log($"Sent marker: {markerLabel}");
    }

    public void SendMarker(string markerLabel, float value)
    {
        
        string[] sample = new string[] { markerLabel, value.ToString("F3") }; // 3 decimal places
        markerOutlet.push_sample(sample);
        Debug.Log($"Sent marker: {markerLabel}, Value: {value}");
        
    }

    public void sendInitialConfig()
    {
        //send markers in the form ("key":value)
        //Debug.Log("Sending markers = " + $"subjectID:{GameManager.Instance.subjectNum}" + $"frequencies:{string.Join(",", GameManager.Instance.frequencies)}" +
           // $"n_harmonics:{GameManager.Instance.nHarmonics}" + $"confidenceThreshold:{GameManager.Instance.threshold}");
        SendMarker($"subjectID:{GameManager.Instance.subjectNum}");
        SendMarker($"frequencies:{string.Join(",", GameManager.Instance.frequencies)}");
        SendMarker($"n_harmonics:{GameManager.Instance.nHarmonics}");
        SendMarker($"confidenceThreshold:{GameManager.Instance.threshold}");
        SendMarker("config_done");
        Debug.Log("Configuration sent via LSL_Manager.");
    }

    private IEnumerator InitializeClassifierInlet()
    {
        yield return new WaitForSeconds(2f); // Allow LSL network to initialize
        StreamInfo[] results = LSL.LSL.resolve_stream("type", InletStreamType);

        if (results.Length > 0)
        {
            classifierInlet = new StreamInlet(results[0]);
            Debug.Log("LSL Classifier Inlet connected.");
        }
        else
        {
            Debug.LogWarning("No BCIOutput stream found.");
        }
    }

   

    // Subscribe to events
    private void OnEnable()
    {
        //MuseumManager.OnRequestStimulus += HandleStimulusRequest;
        MuseumManager.OnStimuliStart += (Action<string>)SendMarker;
        //MuseumManager.SendMarker += (Action<string>)SendMarker; 
    }

    //Unsuscribe to events
    private void OnDisable()
    {
        //MuseumManager.OnRequestStimulus -= HandleStimulusRequest;
        MuseumManager.OnStimuliStart -= (Action<string>)SendMarker;
        //MuseumManager.SendMarker -= (Action<string>)SendMarker;
    }

    private void OnDestroy()
    {
        if (markerOutlet != null)
        {
            markerOutlet.Close();
            //markerOutlet.Dispose(); // Une when you are completely done with the outlet (ex. onAplicationQuit)
            markerOutlet = null;
            Debug.Log("Marker outlet closed.");
        }

        if (classifierInlet != null)
        {
            classifierInlet.close_stream(); // optional but good practice
            classifierInlet = null;
            Debug.Log("Classifier inlet closed.");
        }
    }


}
